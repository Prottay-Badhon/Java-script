<?php
$_GET["roll"];
if(roll=="Badhon"){
	echo $_GET["roll"]
}
else 
	echo "No match";


?>