var object1={  
           firstName:"Prottay",
           lastName:"Badhon",
           fulName:function(){
		      return this.firstName+" "+this.lastName;
		   
		               }
          };
		  
		var  object2=object1;
		    object1={};
		  document.write(object2.fulName());
