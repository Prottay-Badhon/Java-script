function TaxCalculator(price,taxPersent){
	var price;
var taxPersent;
var taxRate=taxPersent/100;
var totalTax=price*taxRate;
var totalPrice=price+totalTax;


	return(totalPrice);
	
}
	        
	document.write("Total price is="+TaxCalculator(150,10))	;		 
	