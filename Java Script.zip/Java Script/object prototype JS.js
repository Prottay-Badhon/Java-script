function stringProcess(a,b,c){
      this.name=a;
	  this.id=b;
	  this.session=c;
	  this.address=function(){
		         return "Name:"+this.name+"<br/>Id:"+this.id+"<br/>session:"+this.session+"<br>";
	         }
     }
		
		 

	function TotalResult(s,h,v){
	   this.ssc=s;
	   this.hsc=h;
	   this.versity=v;
	   this.result=function(){
		   return "SSC:"+this.ssc+"<br/> HSC:"+this.hsc+"<br/>versity:"+this.versity;
	   }
	
	 }		
		 stringProcess.prototype=new TotalResult("5.00","5.00","3.25");//prototype chain should be at TOP//
		   var student1=new stringProcess("Badhon","18701038","17-18");
		  	  
	 document.write(student1.address());
	 document.write("<br/><b>Student Result:</b><br/><br/>");
    document.write(student1.result());
	
	
		 
		 
		  
		