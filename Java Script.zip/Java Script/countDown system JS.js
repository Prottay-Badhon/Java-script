var cd;
var time;
function countDown(){
	document.getElementById("Demo1").innerHTML="The count down has been started.....";
	time=10;
	startCountDown();
	
}
  function startCountDown(){
	   if(time==0){
		  document.getElementById("Demo3").innerHTML="Go";
	           }
	  if(time>=0){ 
		  document.getElementById("Demo2").innerHTML=time;
		 time--;
	  
		  if(time>=0){
			  
		    cd=setTimeout(" startCountDown()",1000);
		
	  
		  }
    }
	
  }  
  function clearCountDown(){
	  clearTimeout(cd);
	  document.getElementById("Demo").innerHTML="The countDown has been stopped";
  }