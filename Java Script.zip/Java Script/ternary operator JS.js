 function check(){
	 var age =document.getElementById("age").value;;
	 var voteable;
	 voteable=(age<18)?"too young ":"old enough";
	 document.getElementById("ageDiv").innerHTML=voteable;
 }	    