var i=0;
var x=setInterval(function(){
	i++;
	 alert("welcome guyes");
     if(i==4){
		 clearInterval(x);
	 }
   },1000
)