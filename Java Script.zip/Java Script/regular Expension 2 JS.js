
function show(){
	document.getElementById("textArea").value= "";
var input=document.getElementById("textInput").value;
var result=input.match(/\d+/g);
for(var i=0;i<result.length;i++){
document.getElementById("textArea").value +=result[i]+"\n";
}
}