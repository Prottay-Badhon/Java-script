//function show(){
	
	//var name=document.getElementById("Demo").innerHTML; 
	//var Badhon,Bad;
	//Badhon=name.replace("Microsoft","w3school");
	
	//document.write(Badhon);
	//document.getElementById("Demo").innerHTML=Badhon;
	
//}

//two method is used to change same type of string//

  function  show(){
	  var name=document.getElementById("Demo").innerHTML;
	  var result=name.replace(/Microsoft/g,"w3school");
	  document.write(result);
  }