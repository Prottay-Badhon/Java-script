function search1(){
	var book=document.getElementById("inputDemo");
	var ebook=book.value;
	var Alamri1=["Bangla","English","ICT","MATH","EEE","CSE"];
	var Alamri2=["GEO","History","chemistry","physics","Epic","পথের পাচালি "];
	var Alamri3=["বাধন","N","O","P","Q","R"];
	var result1=Alamri1.indexOf(ebook);
	var result2=Alamri2.indexOf(ebook); 
	var result3=Alamri3.indexOf(ebook);
	if(result1==-1 && result2==-1 &&  result3==-1){
	
	 
          
							alert(" not found");
				  }
	else if(result1!=-1){
		alert("Found on Alamri 1");
		
	}
	
	else if(result2!=-1){
		alert("Found on Alamri 2");
		
	}
	else if(result3!=-1){
		alert("Found on Alamri 3");
		
	}
	else {
		alert("please write a book name");
		
	}
	
	
}















