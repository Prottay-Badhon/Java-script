var name=["Badhon","Firoj","Shakib","Shihab"];

//var seller=
var fruit=[" banana" ,"mango" ,"Lici" ,"orange" ,"lemon"];
var result=name.concat(fruit,["Robin","Robert","Antenio","Ronchi"]);
document.getElementById("Demo").innerHTML=result;
