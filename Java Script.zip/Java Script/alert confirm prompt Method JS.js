var name=prompt("please enter your name");
if (name==""){
	alert("The field must not be empty");
}

else{
	document.write("your name is "+name+"</br>You may go now</br>");
}

//Bellow program is anoter topics//
  
  var x="B";
document.write(parseInt(x,16));
document.write("</br>"+Number(x));
document.write("</br>");
//Bellow program is anoter topics//

var x=100;
  function myFunction(){
	   var x=230;
	    document.write(x);
	  return false;
	
  }
document.write(x);
	  