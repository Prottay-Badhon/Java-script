
document.getElementById("secondButton").addEventListener("click",function(){
             
	    document.getElementById("Demo").setAttribute("style","display:block;transition:2s;transform:rotate(-360deg)");
    })
                              
							  
		
document.getElementById("firstButton").addEventListener("click",function(){
             
	    document.getElementById("Demo").setAttribute("style","display:block;opacity:1;transition:2s;transform:rotate(360deg)");
    })
						  