function Name1(f,L){
	    var firstName=f;
		var lastName=L;
		this.fullName=firstName+lastName;
		return this.fullName;
      
	  }
	
	   
	   
	   function Calculation(x,y){
	    var num1=x;
		var num2=y;
		this.sum=num1+num2;
		return this.sum;
      
	  }
	   Name1.prototype=new Calculation(10,29);//protype chain should be TOP//
	   var objt1=new Name1("prottay","badhon");
	  
	  
	
	  
	  document.write(objt1.sum);
	   