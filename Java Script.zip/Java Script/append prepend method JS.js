document.querySelector("#Demo").prepend(document.createElement("h2"));
document.querySelector("#Demo h2").innerHTML="My name is";
document.querySelector("#Demo h2").append(" khan");
document.querySelector(".Demo2").setAttribute("style","background:red");
//document.querySelector(".Demo2").className="Newclass name";
document.querySelector(".Demo2").classList.add("midClass");
document.querySelector(".Demo2").setAttribute("style","background:red");
document.querySelector(".Demo2").setAttribute("style","background:red");
function show(){
 document.getElementById("lastDiv").innerHTML="Hi! baby";
}
function hide(){
	document.getElementById("lastDiv").innerHTML="";
}