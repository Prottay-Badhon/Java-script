var n=document.getElementById('n1').value=0;

function calculate1(){
	var n=document.getElementById('n1').value;

	var result=Math.abs(n);
	
	document.getElementById("show").innerHTML=result;
	
	}
	


function calculate2(){
	var n=document.getElementById('n1').value;

	var result=Math.round(n);
	
	document.getElementById("show").innerHTML=result;
	
	}
	


function calculate3(){
	var n=document.getElementById('n1').value;
     var num=n*22/7/180;
	var result=Math.sin(num);
	
	document.getElementById("show").innerHTML=result;
	
	}

function calculate4(){
	var n=document.getElementById('n1').value;
    var num=n*22/7/180;
	var result=Math.cos(num);
	
	document.getElementById("show").innerHTML=result;
	
	}
	

function calculate5(){
	var n=document.getElementById('n1').value;
    var num=n*22/7/180;
	var result=Math.tan(num);
	
	document.getElementById("show").innerHTML=result;
	
	}
	

function calculate6(){
	var n=document.getElementById('n1').value;

	var result=Math.log(n);
	
	document.getElementById("show").innerHTML=result;
	
}
function calculate7(){
	var n=document.getElementById('n1').value;

	var result=Math.floor(n);
	
	document.getElementById("show").innerHTML=result;
	
	}
	

function calculate8(){
	var n=document.getElementById('n1').value;

	var result=Math.ceil(n);
	
	document.getElementById("show").innerHTML=result;
	
	}
	
	

function calculate9(){
	var n=document.getElementById('n1').value;

	var result=Math.sqrt(n);
	
	document.getElementById("show").innerHTML=result;
	
	}
	
function calculate10(){
	var n=document.getElementById('n1').value;

	var result=Math.random(n);
	
	document.getElementById("show").innerHTML=result;
	
	}
	
function calculate11(){
	var n=document.getElementById('n1').value;

	var result=Math.max(n,prompt("Enter Number to compare"));
	
	document.getElementById("show").innerHTML=result+" is maximum";
}
		
function calculate12(){
	var n=document.getElementById('n1').value;

	var result=Math.min(n,prompt("Enter Number to compare"));
	
	document.getElementById("show").innerHTML=result+" is minimum";
	
	}
	


		
function calculate13(){
	var n=document.getElementById('n1').value;

	var result=Math.abs(n);
	
	document.getElementById("show").innerHTML=result;
	
	}
	


		
function calculate14(){
	
  var result=22/7;
	 
	
	document.getElementById("show").innerHTML=result;
	
	}
	


		
function calculate15(){
	
  var n=document.getElementById('n1').value;
  function myFact(n){
	
	if(n==0){
		return 1;
	}
	else{
		return n*myFact(n-1);
    }
 }
  
	 
	
	document.getElementById("show").innerHTML=myFact(n);
	
	}
	
function calculate16(){reload;}

//number function will be large to the system.it should be avoided;
function calculateNumber9(){

	var n=document.getElementById('n1').value= 9;
}



function calculateNumber8(){

	var n=document.getElementById('n1').value= 8;
}



function calculateNumber7(){

	var n=document.getElementById('n1').value= 7;
}
function calculateNumber6(){

	var n=document.getElementById('n1').value= 6;
}

function calculateNumber5(){
	var n=document.getElementById('n1').value= 5;
}

function calculateNumber4(){
	var n=document.getElementById('n1').value= 4;
}


function calculateNumber3(){
	var n=document.getElementById('n1').value= 3;
}


function calculateNumber2(){
	var n=document.getElementById('n1').value= 2;
}











