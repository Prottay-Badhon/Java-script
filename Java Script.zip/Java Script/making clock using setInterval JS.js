

function clock(){
var date=new Date()
var hour=date.getHours();
var minute=date.getMinutes();
var second=date.getSeconds();
document.getElementById("hr").innerHTML=hour;
document.getElementById("mnt").innerHTML=": "+minute;
document.getElementById("sond").innerHTML=":"+second;
}
setInterval(clock,1000);
 
