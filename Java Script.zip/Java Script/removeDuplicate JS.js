var name=["my name is badhon"];
var useOneTime= [];
for(var i=0;i<name.length;i++){
  var selected=name[i];
  if(useOneTime.indexOf(selected)==-1){
	  useOneTime.push(selected);
  }
	
}
document.write(useOneTime);


    var sentence="My name is badhon my father name is Bazlur Rashid";
	var output = "";
   
    for(var i = 0; i < sentence.length; i++){
            var letter = sentence[ i ];
            if(output.indexOf(letter) == -1){
                output = output + letter;
            }
    }
	document.write(output);
                      
    var n1=["jitu","mitu","pitu","janu","jitu","mitu","jitu"];
	var selected= [];
    count=0;
	for(var i=0;i<n1.length;i++){
		var name=n1[i];
		if(selected.indexOf(name)==-1){
			selected.push(name);
		    count++;
			
		}
   

	
}
if(count%2==0){
				document.write("Even times");
			}
document.write(selected);
document.write(count);
document.write("</br>");

//check palindrome programe//

var name="madam";
var str="";
for(var i=name.length-1;i>=0;i--){
	var rev=name[i];
	str=str+rev;
	
}
if(str==name){
		document.write("palindrome");
		
	}
	else{
		document.write("not palindrome");
	}
	
document.write(str+"</br>");
document.write(name);

//reverse word in a sentence//

var count="";
var sentence="I am a god boy";


    var reverseText = "";
	var word="My name is Badhon";
    var words = text.split(" ");
    
    for(var i = words.length - 1; i>=0; i--){
        var word = words[ i ];
        reverseText = reverseText + " "+ word;
    }
	document.write(reverseText);


















   
      
