function EmailVerify(){
	var getEmail=document.getElementById("Demo");
  var email=getEmail.value;
	var emaliVr=/([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})/;
	
	getEmail.style.color="white";
	if(emaliVr.test(email)){
		getEmail.style.color="green";
	}
	else{
		getEmail.style.color="red";
	}
}