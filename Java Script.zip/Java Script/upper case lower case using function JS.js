 function lowerToUpper(name){
	 var show=document.querySelector("Demo");
	 var name;
	 var result;
	 result=name.toUpperCase();
	 return result;
 }
 document.write(show);
 document.write(lowerToUpper("I want to marry  you"));
	 var badhon;
 document.write("The link is:"+badhon.link(https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/link));
	 