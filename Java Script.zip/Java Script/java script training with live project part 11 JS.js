function show(){
	 var name=document.getElementById("inputBox").value;
	 var text;
	 
	 switch(name){
		 case "java":
		 text="I love java";
		 break;
		 
		 case "php":
		 text="webdeveloping language";
		 break;
		 case "html":
		 text="Hyper text mark Up language";
		 break;
		 case "css3":
		 text="casceding stylesheet";
		 break;
		 default:text="unkown";
	 }
	document.getElementById("Demo").innerHTML=text;	 
}		 