function check(num,color){
	 
	 var array=[1,2,6,9,0,10,5,4];
     var colorArray=["Red","Blue","green","white"];
	 var loc=array.indexOf(num);
	 var clrName=colorArray.indexOf(color);
	 if(loc>-1 && clrName>-1){
		 document.write("Both The number and color is exist");
		 
	 }
	 else if(loc>-1 || clrName>-1){
		  document.write("Either The number or the color is exist");
	 }
	 else {
		 document.write(" Both The number and the color is not! exist");
	 }
}

 check(8,"h");