    String.prototype.reverse=function (){
	var result="";
	var name="A B C D";
     var i=name.length;
	 while(i>0){
	result+=this.substring(i-1,i);
	   i--;
	 } 
	 return result;
}
document.write(name.reverse());
