function name(n1,n2){
	this. nam1=n1;
	this. nam2=n2;
	this. totalName=function(){
		return this.nam1+" "+this.nam2;
	}
	
}

   name.prototype.nam3="Bonhi";  //acts as global veriable when use Object//
   var objt=new name("Prottay","Badhon<br/>");
      objt.nam3="Rafik<br/>";
  document.write(objt.totalName());
  document.write(objt.nam3);  //first object call then prototype call//
   document.write( name.prototype.nam3);  //acts as static variable//