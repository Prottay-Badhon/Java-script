document.querySelector("#showMe").addEventListener("click",show);
function show(){
	             document.querySelector("h1").setAttribute("style","opacity:1;transform:scaleX(3.2)");
}


document.querySelector("#hideMe").addEventListener("click",hide);
function hide(){
	             document.querySelector("h1").setAttribute("style","transform:scaleX(0);opacity:0");
				 
}