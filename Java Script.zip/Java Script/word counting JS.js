function word(string){
	var name=string ;
	var count=0;
	var i;
	for(i=0;i<name.length;i++){
		if(name[i]== " "){
			count++;
		}
		
	}
	count++;
	document.write(count);
	document.write("<br>");
	
}
word("Agami eid er por");

function dotedPragraph(){
	var para="In the majority of cases when students try to structure their texts,paying SOME attention to an intro-body-conclusion format and instinctively.";
var count=0;
   for(i=0;i<para.length;i++){
	   if(para[i]== " " || para[i]=="." || para[i]=="  " || para[i]=="?"  || para[i]=="!" || para[i]==";" || para[i]==":" || para[i]=="," || para[i]==": " || para[i]=="; " || (para[i]==","&& para[i]==" ") || para[i]=="-" ) {
		  count++; 
	   }
   }
   document.write(count);
   document.write("<br>");
}
dotedPragraph();
 
 function vowel(bakko){
	 var name=bakko;
  var count=0;
	 for(i=0;i<name.length;i++){
		 if(name[i]=="a" || name[i]=="e" || name[i]=="i" || name[i]=="o" || name[i]=="u"){
			 count++;
		 }
			
		 
	 }
	 document.write(count+"<br>");
	 
 }
vowel("In the majority of cases when students try to structure their texts,paying SOME attention to an intro-body-conclusion format and instinctively.");


function array(checkName){

	var name=checkName;
	var selected=["Badhon","Ruhul","Chayan","Rafik","Misbah","Kashem","Rakib"];
	var loc=selected.indexOf(name);
	
		if(loc==-1){
			document.write("Not selected");
			
		}
		else {
			document.write("selected");
		}
}
array("Rafik");





