function calc1(b){
	
	//this variable is public//
	
	this. num1=10;
	this. num2=b;
	this. sum=function(){
		return this.num1+this.num2;
	}
	

}
         var sumObjt=new calc1(20);
          document.write(sumObjt.sum());
                
	
