//factorial by for loop!//
/*
var i;
function factorial(num){
	var n=num,result=1;
for(i=1;i<=n;i++){
	  
	 result=result*i;
	 
  } 
return result;
}
document.write(factorial(5));
*/



//using recursion!!!

function myFact(num){
	
	if(num==0){
		return 1;
	}
	else{
		return num*myFact(num-1);
 }
}
  document.write( "Factorial is: "+myFact(4));
  
  