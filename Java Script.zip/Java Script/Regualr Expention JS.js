var name="My name is Badhon";
document.getElementById("Demo2").innerHTML=name;
function Mysearch(){
	

	var result=name.search(/Badhon/);
	
	document.getElementById("Demo").innerHTML=result;
}

function Myreplace(){
	
	var result=name.replace('Badhon','Prottay');
	document.getElementById("Demo3").innerHTML=result;
	
}
function MyTest(){
	var result=/d/.test(name);
	document.getElementById("Demo4").innerHTML=result;
}
function MyExeC(){
	var result=/my/i.exec(name);
	document.getElementById("Demo5").innerHTML=result;
}