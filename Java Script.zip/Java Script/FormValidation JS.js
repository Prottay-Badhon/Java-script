function EmailVerify(){
	var getEmail=document.getElementById("Demo2");
  var email=getEmail.value;
	var emaliVr=/([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})/;
	
	getEmail.style.color="white";
	if(emaliVr.test(email)){
		getEmail.style.color="green";
	}
	else{
		getEmail.style.color="red";
	}
}

function show2(){
	var email=document.getElementById("Demo2").value;
	if(email== ""){
		alert("please enter your valid email.")
	}
	else{
		alert("your email is:"+email);
	}
}

function show1(){
	var pass=document.getElementById("Demo1").value;
	
	if(pass!=0){
	alert("password is veryfied");
	}
	else {
		
		alert("please enter your valid password");
	}
	
	
}

function DateVeryfie(){
	var getDate=document.getElementById("Demo3");
	var date=getDate.value;
	var regExp=/(^((([1-9]|1[0-9]|2[0-8])[/]([1-9]|1[012]))|((29|30|31)[/](0[13578]|1[02]))|((29|30)[/]([4,6,9]|11)))[/](19|[2-9][0-9])\d\d$)|(^29[-]02[/](19|[2-9][0-9])(00|04|08|12|16|20|24|28|32|36|40|44|48|52|56|60|64|68|72|76|80|84|88|92|96)$)/;
	if(regExp.test(date)){
		alert("your Date of birth is veryfied");
	}
	else{
		alert("Please enter valid Birthday");
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	