function show(form){
	var getMail=form.inputBox.value;
	if(getMail==""){
		alert("enter valid email");
	}
	else{
		alert("verfied");
	}
}



function docal(form, inputBox){
	var num=form.inputBox.value;
	var result=Math.sqrt(num);
	document.getElementById("root").innerHTML=result;
	
}