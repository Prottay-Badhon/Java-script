document.getElementById("Demo").setAttribute("style","background-color: rebeccapurple;padding:5px;height:100px;margin-right:100px");
document.getElementById("firstButton").addEventListener("click",show);
function show(){
	
	alert("welcome");
	document.getElementById("Demo").setAttribute("style","background-color:red;");
	
}